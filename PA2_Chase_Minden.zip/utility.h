#include <iostream>

using namespace std;

enum Error_code { success, range_err, underflow, overflow, fail, not_present, duplicate_error, 
                  entry_inserted, entry_found, internal_error };
